from haic_agent.adaptive_avoidance_runtime import AdaptiveAvoidanceAgent
class Agent:
    def __init__(self): self.driver = AdaptiveAvoidanceAgent()
    def reset(self, observation): self.driver.reset(observation)
    def act(self, observation): return self.driver.act(observation)
    def last_step_diagnostics(self): return self.driver.last_step_diagnostics()

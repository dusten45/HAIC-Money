# Source-bound optimized submission export; CPU, pixels/action history only.
import time

"""Internal public-mechanics predictor, initialized from estimated observations only.

Adapted from core/vendor/car_dynamics.py; rendering and telemetry access omitted.
Prediction world contains only the reconstructed car; no real environment state.

MIT License

Copyright (c) 2026 2026-HAIC

Portions derived from Gymnasium:
Copyright (c) 2016 OpenAI
Copyright (c) 2022 Farama Foundation

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""
import math
import numpy as np
import Box2D
from Box2D.b2 import fixtureDef, polygonShape, revoluteJointDef

SIZE = 0.02
ENGINE_POWER = 100000000 * SIZE * SIZE
WHEEL_MOMENT_OF_INERTIA = 4000 * SIZE * SIZE
FRICTION_LIMIT = (
    1000000 * SIZE * SIZE
)
WHEEL_R = 27
WHEEL_W = 14
WHEELPOS = [(-55, +80), (+55, +80), (-55, -82), (+55, -82)]
HULL_POLY1 = [(-60, +130), (+60, +130), (+60, +110), (-60, +110)]
HULL_POLY2 = [(-15, +120), (+15, +120), (+20, +20), (-20, 20)]
HULL_POLY3 = [
    (+25, +20),
    (+50, -10),
    (+50, -40),
    (+20, -90),
    (-20, -90),
    (-50, -40),
    (-50, -10),
    (-25, +20),
]
HULL_POLY4 = [(-50, -120), (+50, -120), (+50, -90), (-50, -90)]
WHEEL_COLOR = (0, 0, 0)
WHEEL_WHITE = (77, 77, 77)
MUD_COLOR = (102, 102, 0)


class _Mechanics:
    def __init__(self, world, init_angle, init_x, init_y, grass_friction_multiplier=0.6):
        self.world: Box2D.b2World = world
        self.grass_friction_multiplier = grass_friction_multiplier
        self.grip_multiplier = 1.0
        self.engine_multiplier = 1.0
        self.steering_multiplier = 1.0
        self.hull: Box2D.b2Body = self.world.CreateDynamicBody(
            position=(init_x, init_y),
            angle=init_angle,
            fixtures=[
                fixtureDef(
                    shape=polygonShape(
                        vertices=[(x * SIZE, y * SIZE) for x, y in HULL_POLY1]
                    ),
                    density=1.0,
                ),
                fixtureDef(
                    shape=polygonShape(
                        vertices=[(x * SIZE, y * SIZE) for x, y in HULL_POLY2]
                    ),
                    density=1.0,
                ),
                fixtureDef(
                    shape=polygonShape(
                        vertices=[(x * SIZE, y * SIZE) for x, y in HULL_POLY3]
                    ),
                    density=1.0,
                ),
                fixtureDef(
                    shape=polygonShape(
                        vertices=[(x * SIZE, y * SIZE) for x, y in HULL_POLY4]
                    ),
                    density=1.0,
                ),
            ],
        )
        self.hull.color = (0.8, 0.0, 0.0)
        self.wheels = []
        self.fuel_spent = 0.0
        WHEEL_POLY = [
            (-WHEEL_W, +WHEEL_R),
            (+WHEEL_W, +WHEEL_R),
            (+WHEEL_W, -WHEEL_R),
            (-WHEEL_W, -WHEEL_R),
        ]
        for wx, wy in WHEELPOS:
            front_k = 1.0 if wy > 0 else 1.0
            w = self.world.CreateDynamicBody(
                position=(init_x + wx * SIZE, init_y + wy * SIZE),
                angle=init_angle,
                fixtures=fixtureDef(
                    shape=polygonShape(
                        vertices=[
                            (x * front_k * SIZE, y * front_k * SIZE)
                            for x, y in WHEEL_POLY
                        ]
                    ),
                    density=0.1,
                    categoryBits=0x0020,
                    maskBits=0x001,
                    restitution=0.0,
                ),
            )
            w.wheel_rad = front_k * WHEEL_R * SIZE
            w.color = WHEEL_COLOR
            w.gas = 0.0
            w.brake = 0.0
            w.steer = 0.0
            w.phase = 0.0
            w.omega = 0.0
            w.skid_start = None
            w.skid_particle = None
            rjd = revoluteJointDef(
                bodyA=self.hull,
                bodyB=w,
                localAnchorA=(wx * SIZE, wy * SIZE),
                localAnchorB=(0, 0),
                enableMotor=True,
                enableLimit=True,
                maxMotorTorque=180 * 900 * SIZE * SIZE,
                motorSpeed=0,
                lowerAngle=-0.4,
                upperAngle=+0.4,
            )
            w.joint = self.world.CreateJoint(rjd)
            w.tiles = set()
            w.userData = w
            self.wheels.append(w)
        self.drawlist = self.wheels + [self.hull]
        self.particles = []

    def gas(self, gas):
        gas = np.clip(gas, 0, 1)
        for w in self.wheels[2:4]:
            diff = gas - w.gas
            if diff > 0.1:
                diff = 0.1
            w.gas += diff

    def brake(self, b):
        for w in self.wheels:
            w.brake = b

    def steer(self, s):
        self.wheels[0].steer = s
        self.wheels[1].steer = s

    def step(self, dt):
        for w in self.wheels:
            dir = np.sign(w.steer - w.joint.angle)
            val = abs(w.steer - w.joint.angle)
            w.joint.motorSpeed = (
                dir * min(50.0 * val, 3.0) * self.steering_multiplier
            )

            grass = True
            friction_limit = FRICTION_LIMIT * self.grass_friction_multiplier
            for tile in w.tiles:
                friction_limit = max(
                    friction_limit, FRICTION_LIMIT * tile.road_friction
                )
                grass = False
            friction_limit *= self.grip_multiplier

            forw = w.GetWorldVector((0, 1))
            side = w.GetWorldVector((1, 0))
            v = w.linearVelocity
            vf = forw[0] * v[0] + forw[1] * v[1]
            vs = side[0] * v[0] + side[1] * v[1]


            w.omega += (
                dt
                * (ENGINE_POWER * self.engine_multiplier)
                * w.gas
                / WHEEL_MOMENT_OF_INERTIA
                / (abs(w.omega) + 5.0)
            )
            self.fuel_spent += dt * ENGINE_POWER * w.gas

            if w.brake >= 0.9:
                w.omega = 0
            elif w.brake > 0:
                BRAKE_FORCE = 15
                dir = -np.sign(w.omega)
                val = BRAKE_FORCE * w.brake
                if abs(val) > abs(w.omega):
                    val = abs(w.omega)
                w.omega += dir * val
            w.phase += w.omega * dt

            vr = w.omega * w.wheel_rad
            f_force = -vf + vr
            p_force = -vs


            f_force *= 205000 * SIZE * SIZE
            p_force *= 205000 * SIZE * SIZE
            force = np.sqrt(np.square(f_force) + np.square(p_force))

            if abs(force) > friction_limit:
                f_force /= force
                p_force /= force
                force = friction_limit
                f_force *= force
                p_force *= force

            w.omega -= dt * f_force * w.wheel_rad / WHEEL_MOMENT_OF_INERTIA

            w.ApplyForceToCenter(
                (
                    p_force * side[0] + f_force * forw[0],
                    p_force * side[1] + f_force * forw[1],
                ),
                True,
            )



class _ShadowRoad:
    road_friction = 1.0


class ShadowCar(_Mechanics):
    """Local coordinates: x right, y forward; positive yaw turns left.

    Reset inputs are estimates from public pixels or previous actions. Scalar
    forward/lateral speeds describe hull center-of-mass velocity. RPM is wheel
    angular velocity in rad/s, not revolutions/minute. Omitting RPM assumes
    rolling tires; that assumption is intentionally exposed for diagnostics.
    """
    def __init__(self):
        super().__init__(Box2D.b2World(gravity=(0, 0)), 0, 0, 0)
        self.world.warmStarting = False
        road = _ShadowRoad()
        for w in self.wheels:
            w.tiles.add(road)

    def reset(self, forward_speed, yaw_rate, wheel_angle, *, lateral_speed=0.,
              throttle=0., omegas=None, friction=1.):
        self.hull.position = (0, 0)
        self.hull.angle = 0
        self.hull.linearVelocity = (float(lateral_speed), float(forward_speed))
        self.hull.angularVelocity = float(yaw_rate)
        self.grip_multiplier = float(friction)
        center = self.hull.worldCenter
        for i, (w, anchor) in enumerate(zip(self.wheels, WHEELPOS)):
            x, y = anchor[0] * SIZE, anchor[1] * SIZE
            w.position = (x, y)
            w.angle = float(wheel_angle) if i < 2 else 0.
            w.linearVelocity = (lateral_speed-yaw_rate*(y-center.y),
                                forward_speed+yaw_rate*(x-center.x))
            w.angularVelocity = float(yaw_rate)
            w.gas = float(throttle) if i >= 2 else 0.
            w.brake = 0.
            w.steer = float(wheel_angle) if i < 2 else 0.
            fw = w.GetWorldVector((0, 1))
            w.omega = (float(omegas[i]) if omegas is not None else
                       (fw.x*w.linearVelocity.x+fw.y*w.linearVelocity.y)/w.wheel_rad)
        self.world.ClearForces()

    def step(self, action, steps=1):
        """Advance exact 20ms public steps. Action steering is right-positive."""
        for _ in range(steps):
            self.steer(-float(action[0]))
            self.gas(float(action[1]))
            self.brake(float(action[2]))
            super().step(.02)
            self.world.Step(.02, 180, 60)
        return (float(self.hull.position.x), float(self.hull.position.y),
                float(self.hull.angle), float(self.hull.linearVelocity.length),
                float(self.hull.angularVelocity))


_RPM_COEFFICIENTS = np.array([[21.152569617136912, 132.7205723146679, 40.577256872053574, -3.8915732080655503], [409.8502510704804, 155.40306218906187, 5.847482644730661, -1.2010219155385045], [5.263221102880834, -342.0675489187128, -27.2886226519503, 3.53973730551796], [-15.22031740651515, 514.2683844475864, 35.55255705310872, -7.328977307556208], [19.468778831046947, 77.27707932268008, -47.33604417449891, 10.256369146374226], [-24.314646046543288, -21.973883856310074, 92.25889004474195, -14.249423214963766], [16.76276824546332, 1.6472272359718474, 212.09328081734725, 10.497468787938889], [4.198395629218766, -15.211312324356314, -27.27101120554686, -19.11109394976468], [28.899671023775568, 2.9292676374208213, 42.51667551832618, 351.2375509642337], [-93.55929957024023, 37.14380159749405, -38.13105523760195, -56.2784593310019], [0.0, 0.0, 0.0, 0.0], [1.34390369764688, 0.7004224456057386, 2.179635438930667, 2.0041029485355537]])

def decode_wheel_omega(frame):
    """Four public positive wheel angular velocities; negative/saturated bars ambiguous."""
    crop = np.asarray(frame)[74:82,14:25]
    if not np.any(crop):
        return np.zeros(4)
    return np.maximum(0., np.r_[crop.sum(axis=0),1.] @ _RPM_COEFFICIENTS)


"""Exact-computation cache variant of frozen R6; pixel/action memory only.

Projection geometry and complete-prefix transitions are cached within one act.
Fuel-spent and wheel-phase counters are not controller/dynamics inputs and are
not restored on cache hits; parity applies to predicted physical/controller state.

Seven earlier shifts of the original winning sequence retain identical physics,
collision margin, objective and action lattice. No iterative composition.

Exact-physics short sequence beam MPC. Pixel observations/action memory only.

Road primitives copied from geodesic r1 archive SHA256
36c7a4cbbb5d930708cf639aea9d55e0273490ee962e1994218d12a140296218.
Internal shadow snapshots are predicted states, never real environment state.
"""
import math
import heapq
import cv2
import numpy as np



class _Road:
    PIXELS_X, PIXELS_Y = 1.3608, 1.701
    def __init__(self):
        self.config=dict(road_low=.24,road_high=.52,obstacle_margin=0,clearance=3.)

    def _free_space(self, frame):
        c = self.config
        road = ((frame >= c['road_low']) & (frame <= c['road_high'])).astype(np.uint8)
        # Small image holes arise from aliasing/paint, not only obstacles. Recover
        # the road surface first, then subtract separately identified hazards.
        road = cv2.morphologyEx(road, cv2.MORPH_CLOSE, np.ones((5,5), np.uint8))
        bright = (frame >= .54).astype(np.uint8)
        bright[:5] = 0
        bright[61:] = 0
        count, labels, stats, _ = cv2.connectedComponentsWithStats(bright, 8)
        obstacles = np.zeros_like(road)
        for i in range(1, count):
            x, y, w, h, area = stats[i]
            if 4 <= area <= 90 and 2 <= w <= 11 and 2 <= h <= 12:
                # Component must be surrounded by road, excluding grass islands.
                region = road[max(0,y-2):min(74,y+h+2), max(0,x-2):min(84,x+w+2)]
                if region.mean() > .2:
                    obstacles[labels == i] = 1
        radius = int(c['obstacle_margin'])
        obstacles = cv2.dilate(obstacles, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2*radius+1,2*radius+1)))
        road[74:] = 0
        free = road.copy()
        free[obstacles > 0] = 0
        clearance = cv2.distanceTransform(free, cv2.DIST_L2, 5)
        return free, obstacles, clearance

    @staticmethod
    def _hud_dynamics(frame):
        """Decode instantaneous HUD state, with positive values turning right.

        Pure observation-only calibration from diagnostics/hud_dynamics_calibration;
        no renderer, simulator, or calibration dependency is imported at runtime.
        """
        yaw_crop = frame[74:82,52:75]
        wheel_crop = frame[74:82,31:52]
        yaw_mass = float(yaw_crop[:,:11].sum()-yaw_crop[:,11:].sum())
        wheel_mass = float(wheel_crop[:,:11].sum()-wheel_crop[:,11:].sum())
        yaw = .4580150260806972*yaw_mass+.024360133436811916 if yaw_crop.sum() else 0.
        wheel = .018757917750222175*wheel_mass+.0019537197954649153 if wheel_crop.sum() else 0.
        return -float(yaw), -float(wheel)

    def _motion(self, previous, current):
        """Shared measurement concept independently validated by the rollout lane."""
        old = np.clip(previous * 255, 0, 255).astype(np.uint8)
        new = np.clip(current * 255, 0, 255).astype(np.uint8)
        mask = np.zeros((84, 84), np.uint8)
        mask[4:70, 4:80] = 255
        mask[56:70, 36:48] = 0
        points = cv2.goodFeaturesToTrack(old, 100, 0.015, 4, mask=mask)
        if points is None or len(points) < 6:
            return 0.0, 0.0, False
        moved, status, error = cv2.calcOpticalFlowPyrLK(old, new, points, None,
                                                     winSize=(15, 15), maxLevel=2)
        if moved is None:
            return 0.0, 0.0, False
        keep = (status.ravel() > 0) & (error.ravel() < 30)
        if np.count_nonzero(keep) < 6:
            return 0.0, 0.0, False
        scale = np.array([self.PIXELS_X, self.PIXELS_Y], np.float32)
        before = points.reshape(-1, 2)[keep] / scale
        after = moved.reshape(-1, 2)[keep] / scale
        transform, inliers = cv2.estimateAffinePartial2D(before, after,
                    method=cv2.RANSAC, ransacReprojThreshold=0.8, maxIters=500)
        if transform is None or np.count_nonzero(inliers) < 6:
            return 0.0, 0.0, False
        center = np.array([42.0, 63.0]) / scale
        delta = transform[:, :2] @ center + transform[:, 2] - center
        yaw_rate = -np.arctan2(transform[1, 0], transform[0, 0]) / 0.08
        velocity = np.array([-delta[0], delta[1]]) / 0.08
        slip = np.arctan2(velocity[0], max(0.1, velocity[1]))
        zoom = np.sqrt(np.linalg.det(transform[:, :2]))
        if not (0.96 < zoom < 1.04) or abs(yaw_rate) > 8 or np.linalg.norm(velocity) > 140:
            return 0.0, 0.0, False
        return float(yaw_rate), float(np.clip(slip, -0.8, 0.8)), True

    def _geodesic(self, free, start=(42,58), goal=None):
        """Clearance-weighted 8-connected search with unrestricted later turns."""
        distance = cv2.distanceTransform(free, cv2.DIST_L2, 5)
        allowed = distance >= self.config['clearance']
        sy, sx = int(start[1]), int(start[0])
        # Suppress the rearward road branch locally, without preventing a
        # hairpin from returning below the car away from its departure gate.
        allowed[sy+1:, max(0,sx-18):min(84,sx+19)] = False
        yy,xx = np.nonzero(allowed)
        if not len(xx):
            return np.empty((0,2))
        nearest = np.argmin((xx-sx)**2+(yy-sy)**2)
        sx,sy=int(xx[nearest]),int(yy[nearest])
        costs=np.full((84,84),np.inf); costs[sy,sx]=0.
        parent=np.full((84,84,2),-1,np.int16)
        length=np.zeros((84,84))
        queue=[(0.,sx,sy)]
        moves=[(dx,dy,float(np.hypot(dx,dy))) for dy in (-1,0,1) for dx in (-1,0,1) if dx or dy]
        while queue:
            cost,x,y=heapq.heappop(queue)
            if cost>costs[y,x]+1e-9:
                continue
            for dx,dy,step in moves:
                nx,ny=x+dx,y+dy
                if not (0<=nx<84 and 0<=ny<74 and allowed[ny,nx]):
                    continue
                if dx and dy and not (allowed[y,nx] and allowed[ny,x]):
                    continue
                new=cost+step*(1.+12./(float(distance[ny,nx])+.5)**2)
                if new<costs[ny,nx]:
                    costs[ny,nx]=new;parent[ny,nx]=[x,y]
                    length[ny,nx]=length[y,x]+step
                    heapq.heappush(queue,(new,nx,ny))
        reached=np.isfinite(costs)
        yy,xx=np.nonzero(reached)
        if goal is not None:
            i=np.argmin((xx-goal[0])**2+(yy-goal[1])**2)
        else:
            frontier=(yy<=5)|(xx<=4)|(xx>=79)|(yy>=70)
            # Prefer a visible outgoing road frontier; if it is enclosed by
            # image grass, use the farthest reachable centerline continuation.
            candidates=np.where(frontier & (length[yy,xx]>18))[0]
            if len(candidates):
                # Central exit pixel wins within one opening. Shortest exit
                # avoids tracing unnecessarily around a visible road loop.
                score=costs[yy[candidates],xx[candidates]]-2*distance[yy[candidates],xx[candidates]]
                i=candidates[np.argmin(score)]
            else:
                i=np.argmax(length[yy,xx]+2*distance[yy,xx])
        x,y=int(xx[i]),int(yy[i]);path=[]
        while x>=0:
            path.append([x,y]);x,y=map(int,parent[y,x])
        path=np.array(path[::-1],float)
        if len(path)<3:return path
        original=path.copy()
        # Local constrained elastic smoothing. Every updated pair is densely
        # checked in the image; neither endpoints nor swept segments may cut a
        # corner across the configured sampled-distance clearance threshold.
        for _ in range(35):
            proposed=path.copy()
            proposed[1:-1]=.49*(path[:-2]+path[2:])+.02*original[1:-1]
            points=(proposed[:-1,None,:]*(1-np.linspace(0,1,5)[None,:,None])+
                    proposed[1:,None,:]*np.linspace(0,1,5)[None,:,None])
            px,py=np.rint(points).astype(int).transpose(2,0,1)
            safe=(distance[py,px]>=self.config['clearance']).all(axis=1)
            accept=np.r_[True,safe]&np.r_[safe,True]
            path[accept]=proposed[accept]
        return path

    @staticmethod
    def _geometry(metric):
        arc=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(metric,axis=0),axis=1))]
        curvature=np.zeros(len(metric))
        for i in range(len(metric)):
            lo,hi=max(0,i-6),min(len(metric),i+7)
            if hi-lo<5:continue
            ss=arc[lo:hi]-arc[i]
            px=np.polyfit(ss,metric[lo:hi,0],3)
            py=np.polyfit(ss,metric[lo:hi,1],3)
            dx,dy=px[-2],py[-2]
            curvature[i]=(dy*2*px[-3]-dx*2*py[-3])/max((dx*dx+dy*dy)**1.5,.001)
        return arc,curvature


class _CachedBeam:
    CACHE_CAP=2144
    DEPTH=8
    WIDTH=8
    # Dense rectangular footprint includes hull and wheels. No obstacle dilation
    # is applied; checking this footprint would otherwise double the margin.
    FOOTPRINT=np.array([(x,y) for x in (-1.4,-.7,0,.7,1.4)
                        for y in (-2.4,-1.15,.1,1.35,2.6)],float)

    def __init__(self,config=None,*,project_root=None):
        if config:raise ValueError('beam r1 uses fixed architecture defaults')
        self.road=_Road()
        self.shadow=ShadowCar()
        # Local fixtures are immutable; wheel body transforms remain dynamic.
        self._fixture_cache=[]
        for body in [self.shadow.hull]+self.shadow.wheels:
            polygons=[np.asarray(f.shape.vertices,dtype=np.float64) for f in body.fixtures]
            radius=max(float(np.linalg.norm(poly,axis=1).max()) for poly in polygons)
            self._fixture_cache.append((body,polygons,radius))
        self._collision_free=None
        self.reset()

    def reset(self,observation=None):
        self._clear_act_cache()
        self.throttle=0.
        self.last_steer=0.
        self.slip=0.
        self.diagnostics={}

    def _clear_act_cache(self):
        self._transition_cache={}
        self._memo_hits=0
        self._memo_misses=0
        self._projection_reference=None
        self._projection_arc=None
        self._projection_geometry=None

    @staticmethod
    def _copy_node(node):
        copied=dict(node)
        copied['sequence']=list(node['sequence'])
        copied['state']=(list(node['state'][0]),list(node['state'][1]))
        return copied

    @staticmethod
    def snapshot(shadow):
        bodies=[]
        for b in [shadow.hull]+shadow.wheels:
            bodies.append((tuple(b.position),b.angle,tuple(b.linearVelocity),b.angularVelocity))
        tires=[(w.omega,w.gas,w.brake,w.steer) for w in shadow.wheels]
        return bodies,tires

    @staticmethod
    def restore(shadow,state):
        bodies,tires=state
        for b,s in zip([shadow.hull]+shadow.wheels,bodies):
            b.position=s[0];b.angle=s[1];b.linearVelocity=s[2];b.angularVelocity=s[3];b.awake=True
        for w,s in zip(shadow.wheels,tires):
            w.omega,w.gas,w.brake,w.steer=s
        shadow.world.ClearForces()

    @staticmethod
    def stage_cost(delta_progress,cross_track,heading_error,speed,target_speed):
        # Progress is accumulated for every executed prefix, so waiting cannot
        # earn the same score as a trajectory that traverses the visible route.
        return (-4.*delta_progress+.08*(2.*cross_track**2+3.*heading_error**2
                 +.025*max(speed-target_speed,0.)**2+.003*max(target_speed-speed,0.)**2))

    @staticmethod
    def _decode_speed(frame):
        mass=float(frame[74:83,10:13].sum())
        return float(np.clip(11.426880974069949*mass-2.8567432419448333,0.,140.))

    def _projection(self,position,reference,arc,previous_progress,speed):
        if self._projection_reference is not reference or self._projection_arc is not arc:
            start=reference[:-1];delta=np.diff(reference,axis=0)
            denominator=np.maximum(np.sum(delta*delta,axis=1),1e-8)
            arc_delta=np.diff(arc)
            headings=[math.atan2(d[0],d[1]) for d in delta]
            self._projection_reference=reference
            self._projection_arc=arc
            self._projection_geometry=(start,delta,denominator,arc_delta,headings)
        start,delta,denominator,arc_delta,headings=self._projection_geometry
        fraction=np.clip(np.sum((position-start)*delta,axis=1)/denominator,0,1)
        projected=start+fraction[:,None]*delta
        distance=np.sum((position-projected)**2,axis=1)
        progress=arc[:-1]+fraction*arc_delta
        valid=(progress>=max(0,previous_progress-3.))&(progress<=previous_progress+.08*speed+4.)
        distance=np.where(valid,distance,np.inf)
        index=int(np.argmin(distance))
        heading=headings[index]
        return float(progress[index]),float(np.sqrt(distance[index])),heading

    @staticmethod
    def _collision_mask(free):
        # One rendered pixel of clearance, not a proven state-error bound.
        # Explicit zero border treats outside-image cells as unsafe.
        return cv2.erode(free,np.ones((3,3),np.uint8),iterations=1,
                         borderType=cv2.BORDER_CONSTANT,borderValue=0)

    def _footprint_cost(self,free,x,y,heading):
        """Union of unsafe raster pixel cells touched by full predicted fixtures.

        Convex-polygon/cell SAT includes boundary touches conservatively. Pixel
        cells approximate the image geometry; this is not continuous collision
        detection between the20ms samples. Cost units are unique unsafe cells,
        replacing R3's25sample count, with the original200 multiplier unchanged.
        """
        if self._collision_free is not free:
            self._collision_free=free
            self._unsafe_integral=cv2.integral((free[:74]==0).astype(np.uint8))
        # Rotation-independent bounds of actual hull AND jointed wheel bodies.
        poses=[(float(b.position.x),float(b.position.y),float(b.angle),polys,r)
               for b,polys,r in self._fixture_cache]
        lo_x=math.ceil(min(42+1.3608*(px-r) for px,py,h,polys,r in poses)-.5)
        hi_x=math.floor(max(42+1.3608*(px+r) for px,py,h,polys,r in poses)+.5)
        lo_y=math.ceil(min(63-1.701*(py+r) for px,py,h,polys,r in poses)-.5)
        hi_y=math.floor(max(63-1.701*(py-r) for px,py,h,polys,r in poses)+.5)
        xa,xb=max(0,lo_x),min(83,hi_x)
        ya,yb=max(0,lo_y),min(73,hi_y)
        entirely_inside=lo_x>=0 and hi_x<84 and lo_y>=0 and hi_y<74
        if entirely_inside:
            ii=self._unsafe_integral
            if ii[yb+1,xb+1]-ii[ya,xb+1]-ii[yb+1,xa]+ii[ya,xa]==0:return 0
        yy,xx=np.mgrid[lo_y:hi_y+1,lo_x:hi_x+1]
        xx=xx.ravel();yy=yy.ravel()
        inside=(xx>=0)&(xx<84)&(yy>=0)&(yy<74)
        unsafe=~inside
        unsafe[inside]=free[yy[inside],xx[inside]]==0
        cells=np.column_stack((xx[unsafe],yy[unsafe])).astype(np.float64)
        if not len(cells):return 0
        touched=np.zeros(len(cells),bool)
        for px,py,h,polygons,radius in poses:
            c,sn=math.cos(h),math.sin(h)
            transform=np.array([[1.3608*c,-1.701*sn],[-1.3608*sn,-1.701*c]])
            for local in polygons:
                poly=local@transform+[42+1.3608*px,63-1.701*py]
                possible=(~touched)&np.all(cells+.5>=poly.min(axis=0),axis=1)&np.all(cells-.5<=poly.max(axis=0),axis=1)
                ids=np.flatnonzero(possible)
                if not len(ids):continue
                edges=np.roll(poly,-1,axis=0)-poly
                normals=np.column_stack((-edges[:,1],edges[:,0]))
                projection=poly@normals.T
                centers=cells[ids]@normals.T
                extent=.5*np.abs(normals).sum(axis=1)
                overlap=np.all((centers+extent>=projection.min(axis=0)-1e-9)&
                               (centers-extent<=projection.max(axis=0)+1e-9),axis=1)
                touched[ids[overlap]]=True
        return int(touched.sum())

    @staticmethod
    def _pursuit(node,reference,arc):
        body=node['state'][0][0]
        position=np.array(body[0]);heading=body[1]
        speed=float(np.linalg.norm(body[2]))
        aim_s=min(arc[-1],node['progress']+float(np.clip(4.+.18*speed,5.,12.)))
        aim=np.array([np.interp(aim_s,arc,reference[:,j]) for j in range(2)])-position
        c,s=math.cos(heading),math.sin(heading)
        lateral=c*aim[0]+s*aim[1]
        return math.atan(3.24*2*lateral/max(float(aim@aim),1.)),speed

    def _advance(self,node,action,reference,arc,targets,free,terminal):
        # Complete prefixes include signed-zero bit identity. Initial state,
        # reference, targets and collision mask are fixed throughout this act.
        key=(tuple(tuple(float(v).hex() for v in a)
                   for a in node['sequence']+[action]),bool(terminal))
        cached=self._transition_cache.get(key)
        if cached is not None:
            self._memo_hits+=1
            self.restore(self.shadow,cached['state'])
            return self._copy_node(cached)
        self._memo_misses+=1
        result=self._advance_uncached(node,action,reference,arc,targets,free,terminal)
        if len(self._transition_cache)<self.CACHE_CAP:
            self._transition_cache[key]=self._copy_node(result)
        return result

    def _advance_uncached(self,node,action,reference,arc,targets,free,terminal):
        self.restore(self.shadow,node['state'])
        collision=0
        for _ in range(4):
            x,y,h,v,yaw=self.shadow.step(action)
            collision+=self._footprint_cost(free,x,y,h)
        progress,cross,ref_heading=self._projection(np.array([x,y]),reference,arc,node['progress'],v)
        error=math.atan2(math.sin(-h-ref_heading),math.cos(-h-ref_heading))
        target=float(np.interp(progress,arc,targets))
        cost=node['cost']+self.stage_cost(progress-node['progress'],cross,error,v,target)
        cost+=200.*collision+.03*(action[0]-node['last'])**2
        if terminal:cost+=4.*cross**2+5.*error**2+.03*(v-target)**2
        return dict(cost=cost,progress=progress,state=self.snapshot(self.shadow),
                    unsafe_count=node.get('unsafe_count',0)+collision,
                    sequence=node['sequence']+[action],last=action[0])

    def _completion(self,node,reference,arc,targets,free,depth):
        # Compare every prefix at the SAME full horizon. This feedback rollout
        # is a ranking estimate, not extra accumulated cost on the prefix.
        tail=node
        for future in range(depth+1,self.DEPTH):
            steer,speed=self._pursuit(tail,reference,arc)
            steer=float(np.clip(steer,-.4,.4))
            target=float(np.interp(tail['progress'],arc,targets))
            if speed>target+1.:gas,brake=0.,.65
            elif speed<target-3.:gas,brake=.7,0.
            else:gas,brake=0.,0.
            tail=self._advance(tail,(steer,gas,brake),reference,arc,targets,free,future==self.DEPTH-1)
        return tail['cost']

    def _search(self,reference,arc,targets,free,initial):
        beam=[dict(cost=0.,progress=0.,state=initial,sequence=[],last=self.last_steer)]
        checked=0
        for depth in range(self.DEPTH):
            children=[]
            for node in beam:
                pursuit,_=self._pursuit(node,reference,arc)
                steers=np.unique(np.clip(pursuit+np.array([-.14,0,.14]),-.4,.4))
                for steer in steers:
                    for gas,brake in ((.7,0.),(0.,0.),(0.,.65)):
                        action=(float(steer),gas,brake)
                        child=self._advance(node,action,reference,arc,targets,free,depth==self.DEPTH-1)
                        child['priority']=self._completion(child,reference,arc,targets,free,depth)
                        checked+=4*(self.DEPTH-depth)
                        children.append(child)
            children.sort(key=lambda n:n['priority'])
            beam=children[:self.WIDTH]
        return beam[0],checked

    def act(self,observation):
        self._clear_act_cache()
        obs=np.asarray(observation)
        if obs.shape!=(4,84,84) or not np.isfinite(obs).all() or obs.min()<0 or obs.max()>1:
            self.throttle=0.;self.diagnostics=dict(valid=False)
            return np.array([0.,0.,.5],np.float32)
        frame=obs[-1].astype(np.float32)
        free,obstacles,clearance=self.road._free_space(frame)
        path=self.road._geodesic(free)
        if len(path)<5:
            self.throttle=0.;self.diagnostics=dict(valid=False,path=path.tolist())
            return np.array([self.last_steer*.8,0.,.65],np.float32)
        reference=(path-[42.,63.])/[1.3608,-1.701]
        reference=np.vstack(([0.,0.],reference))
        arc,kappas=self.road._geometry(reference)
        targets=np.clip(np.sqrt(100./np.maximum(abs(kappas),.001)),24.,100.)
        # Unknown continuation beyond the visible route retains corner speed.
        targets[-1]=min(targets[-1],24.)
        for i in range(len(targets)-2,-1,-1):
            targets[i]=min(targets[i],math.sqrt(targets[i+1]**2+130.*(arc[i+1]-arc[i])))
        speed=self._decode_speed(frame)
        yaw,wheel=self.road._hud_dynamics(frame)
        _,measured_slip,flow_valid=self.road._motion(obs[-2],obs[-1])
        if flow_valid:self.slip=float(measured_slip)
        self.slip=float(np.clip(self.slip,-.7,.7))
        omegas=decode_wheel_omega(frame)
        ambiguous=bool(np.any(omegas>340) or np.any(frame[82:84,14:24]>.02))
        self.shadow.reset(speed*math.cos(self.slip),-yaw,float(np.clip(-wheel,-.4,.4)),
                          lateral_speed=speed*math.sin(self.slip),throttle=self.throttle,omegas=omegas)
        initial=self.snapshot(self.shadow)
        # Only the current car-occluded footprint is filled; grass elsewhere is
        # never declared drivable. Future footprint samples must remain on road.
        free[59:68,40:45]=1
        collision_free=self._collision_mask(free)
        best,checked=self._search(reference,arc,targets,collision_free,initial)
        original=best
        best,refinement_shift,refinement_ticks=self._refine(original,reference,arc,targets,collision_free,initial)
        checked+=refinement_ticks
        action=np.array(best['sequence'][0],np.float32)
        self.restore(self.shadow,initial)
        self.shadow.step(action,4)
        h=self.shadow.hull.angle;vel=self.shadow.hull.linearVelocity
        lat=math.cos(h)*vel.x+math.sin(h)*vel.y
        forward=-math.sin(h)*vel.x+math.cos(h)*vel.y
        self.slip=math.atan2(lat,max(forward,.1))
        self.throttle=self.shadow.wheels[2].gas
        self.last_steer=float(action[0])
        self.diagnostics=dict(original_beam_cost=float(original['cost']),
                              original_collision_count=int(original['unsafe_count']),
                              refined_collision_count=int(best['unsafe_count']),
                              refinement_shift=refinement_shift,refinement_raw_ticks=refinement_ticks,
                              valid=True,path=path.tolist(),speed=speed,yaw_rate=yaw,wheel_angle=wheel,
                              flow_valid=flow_valid,rpm_ambiguous=ambiguous,omegas=omegas.tolist(),
                              beam_sequence=best['sequence'],beam_cost=float(best['cost']),
                              beam_progress=float(best['progress']),collision_checked_raw_ticks=checked,
                              predicted_slip=self.slip,target_speed=float(targets[0]))
        self.diagnostics.update(transition_cache_hits=self._memo_hits,
                                transition_cache_misses=self._memo_misses,
                                transition_cache_entries=len(self._transition_cache),
                                memo_skipped_raw_ticks=4*self._memo_hits,
                                actual_search_raw_ticks=4*self._memo_misses)
        return action

    def last_step_diagnostics(self):
        return dict(self.diagnostics)


    @staticmethod
    def _accept_refinement(current,candidate,original):
        # Preserve original/earlier proposal on exact cost ties. The collision
        # ceiling always refers to the immutable original beam winner.
        if (candidate['cost']<current['cost']
                and candidate['unsafe_count']<=original['unsafe_count']):
            return candidate
        return current

    def _refine(self,original,reference,arc,targets,free,initial):
        selected=original
        selected_shift=0
        ticks=0
        original_sequence=tuple(tuple(action) for action in original['sequence'])
        tail_intent=(original_sequence[-1][0],0.,0.)
        for shift in range(1,self.DEPTH):
            desired=original_sequence[shift:]+(tail_intent,)*shift
            node=dict(cost=0.,progress=0.,state=initial,sequence=[],
                      last=self.last_steer,unsafe_count=0)
            for depth,intent in enumerate(desired):
                pursuit,_=self._pursuit(node,reference,arc)
                steers=np.unique(np.clip(pursuit+np.array([-.14,0.,.14]),-.4,.4))
                # np.argmin chooses the first sorted lattice entry on ties.
                steer=float(steers[np.argmin(abs(steers-intent[0]))])
                action=(steer,intent[1],intent[2])
                node=self._advance(node,action,reference,arc,targets,free,
                                   depth==self.DEPTH-1)
                ticks+=4
            previous=selected
            selected=self._accept_refinement(selected,node,original)
            if selected is not previous:selected_shift=shift
        return selected,selected_shift,ticks


class _DeadlineReached(Exception):
    pass

class _FastBeam:
    def _begin_budget(self):
        self._fast_started = time.perf_counter()
        self._fast_stats = dict(search_children_completed=0, refinements_completed=0,
                                transition_calls=0, search_stop='complete',
                                refinement_stop='complete')
        self._fast_completion = None

    def _expired(self):
        return (self._fast_deadline_seconds is not None
                and time.perf_counter() - self._fast_started >= self._fast_deadline_seconds)

    def _advance(self, *args, **kwargs):
        # Always establish one full-horizon candidate before honoring deadline.
        if self._fast_stats['search_children_completed'] and self._expired():
            raise _DeadlineReached
        result = super()._advance(*args, **kwargs)
        self._fast_stats['transition_calls'] += 1
        return result

    def _completion(self, node, reference, arc, targets, free, depth):
        # Same ordered arithmetic and tail controls as the pinned implementation.
        tail = node
        for future in range(depth + 1, self.DEPTH):
            steer, speed = self._pursuit(tail, reference, arc)
            steer = float(np.clip(steer, -.4, .4))
            target = float(np.interp(tail['progress'], arc, targets))
            if speed > target + 1.:
                gas, brake = 0., .65
            elif speed < target - 3.:
                gas, brake = .7, 0.
            else:
                gas, brake = 0., 0.
            tail = self._advance(tail, (steer, gas, brake), reference, arc,
                                 targets, free, future == self.DEPTH - 1)
        self._fast_completion = tail
        return tail['cost']

    def _search(self, reference, arc, targets, free, initial):
        if not getattr(self, '_fast_in_act', False):
            self._begin_budget()
        beam = [dict(cost=0., progress=0., state=initial, sequence=[], last=self.last_steer)]
        incumbent = None
        start_calls = self._fast_stats['transition_calls']
        for depth in range(self.DEPTH):
            children = []
            for node in beam:
                pursuit, _ = self._pursuit(node, reference, arc)
                steers = np.unique(np.clip(pursuit + np.array([-.14, 0., .14]), -.4, .4))
                for steer in steers:
                    for gas, brake in ((.7, 0.), (0., 0.), (0., .65)):
                        if self._fast_stats['search_children_completed'] >= self._fast_max_children:
                            self._fast_stats['search_stop'] = 'child_cap'
                            return incumbent, 4 * (self._fast_stats['transition_calls'] - start_calls)
                        try:
                            action = (float(steer), gas, brake)
                            child = self._advance(node, action, reference, arc, targets,
                                                  free, depth == self.DEPTH - 1)
                            child['priority'] = self._completion(child, reference, arc, targets, free, depth)
                        except _DeadlineReached:
                            self._fast_stats['search_stop'] = 'deadline'
                            return incumbent, 4 * (self._fast_stats['transition_calls'] - start_calls)
                        self._fast_stats['search_children_completed'] += 1
                        completed = self._fast_completion
                        if incumbent is None or completed['cost'] < incumbent['cost']:
                            incumbent = completed
                        children.append(child)
            children.sort(key=lambda n: n['priority'])
            beam = children[:self.WIDTH]
        # When all work finishes, preserve the original beam winner and tie order.
        return beam[0], 4 * (self._fast_stats['transition_calls'] - start_calls)

    def _refine(self, original, reference, arc, targets, free, initial):
        selected, selected_shift = original, 0
        start_calls = self._fast_stats['transition_calls']
        original_sequence = tuple(tuple(action) for action in original['sequence'])
        tail_intent = (original_sequence[-1][0], 0., 0.)
        for shift in range(1, self.DEPTH):
            desired = original_sequence[shift:] + (tail_intent,) * shift
            node = dict(cost=0., progress=0., state=initial, sequence=[],
                        last=self.last_steer, unsafe_count=0)
            try:
                for depth, intent in enumerate(desired):
                    pursuit, _ = self._pursuit(node, reference, arc)
                    steers = np.unique(np.clip(pursuit + np.array([-.14, 0., .14]), -.4, .4))
                    steer = float(steers[np.argmin(abs(steers - intent[0]))])
                    node = self._advance(node, (steer, intent[1], intent[2]), reference,
                                         arc, targets, free, depth == self.DEPTH - 1)
            except _DeadlineReached:
                self._fast_stats['refinement_stop'] = 'deadline'
                break
            self._fast_stats['refinements_completed'] += 1
            previous = selected
            selected = self._accept_refinement(selected, node, original)
            if selected is not previous:
                selected_shift = shift
        return selected, selected_shift, 4 * (self._fast_stats['transition_calls'] - start_calls)

    def act(self, observation):
        self._begin_budget()
        self._fast_in_act = True
        try:
            return super().act(observation)
        finally:
            self._fast_in_act = False
            self.diagnostics.update(fast_beam=dict(
                self._fast_stats, max_search_children=self._fast_max_children,
                deadline_seconds=self._fast_deadline_seconds,
                elapsed_seconds=time.perf_counter() - self._fast_started,
                maximum_transition_calls=8 * self._fast_max_children + 56))

    def reset(self, observation=None):
        result = super().reset(observation)
        self._fast_in_act = False
        self._fast_completion = None
        self._fast_stats = {}
        return result

class _BatchedGeometry:
    def _footprint_cost(self, free, x, y, heading):
        if self._collision_free is not free:
            self._collision_free = free
            self._unsafe_integral = cv2.integral((free[:74] == 0).astype(np.uint8))
        poses = [(float(b.position.x), float(b.position.y), float(b.angle), polygons, radius)
                 for b, polygons, radius in self._fixture_cache]
        lo_x = math.ceil(min(42 + 1.3608 * (px - r) for px, py, h, polys, r in poses) - .5)
        hi_x = math.floor(max(42 + 1.3608 * (px + r) for px, py, h, polys, r in poses) + .5)
        lo_y = math.ceil(min(63 - 1.701 * (py + r) for px, py, h, polys, r in poses) - .5)
        hi_y = math.floor(max(63 - 1.701 * (py - r) for px, py, h, polys, r in poses) + .5)
        xa, xb = max(0, lo_x), min(83, hi_x)
        ya, yb = max(0, lo_y), min(73, hi_y)
        if lo_x >= 0 and hi_x < 84 and lo_y >= 0 and hi_y < 74:
            ii = self._unsafe_integral
            if ii[yb + 1, xb + 1] - ii[ya, xb + 1] - ii[yb + 1, xa] + ii[ya, xa] == 0:
                return 0
        yy, xx = np.mgrid[lo_y:hi_y + 1, lo_x:hi_x + 1]
        xx, yy = xx.ravel(), yy.ravel()
        inside = (xx >= 0) & (xx < 84) & (yy >= 0) & (yy < 74)
        unsafe = ~inside
        unsafe[inside] = free[yy[inside], xx[inside]] == 0
        cells = np.column_stack((xx[unsafe], yy[unsafe])).astype(np.float64)
        if not len(cells):
            return 0
        transforms, offsets = [], []
        for px, py, h, polygons, radius in poses:
            c, sn = math.cos(h), math.sin(h)
            transforms.append([[1.3608 * c, -1.701 * sn], [-1.3608 * sn, -1.701 * c]])
            offsets.append([42 + 1.3608 * px, 63 - 1.701 * py])
        transforms = np.asarray(transforms)
        offsets = np.asarray(offsets)
        touched = np.zeros(len(cells), bool)
        for indices, local in self._geometry_groups:
            poly = local @ transforms[indices] + offsets[indices, None, :]
            possible = (np.all(cells[None, :, :] + .5 >= poly.min(axis=1)[:, None, :], axis=2)
                        & np.all(cells[None, :, :] - .5 <= poly.max(axis=1)[:, None, :], axis=2)
                        & ~touched[None, :])
            # Only the union of broad-phase candidates needs projection. Full
            # per-polygon broad-phase masks are still applied after batched SAT.
            ids = np.flatnonzero(np.any(possible, axis=0))
            if not len(ids):
                continue
            edges = np.roll(poly, -1, axis=1) - poly
            normals = np.stack((-edges[:, :, 1], edges[:, :, 0]), axis=2)
            axes = normals.transpose(0, 2, 1)
            projection = poly @ axes
            centers = cells[ids][None, :, :] @ axes
            extent = .5 * np.abs(normals).sum(axis=2)
            overlap = np.all(
                (centers + extent[:, None, :] >= projection.min(axis=1)[:, None, :] - 1e-9)
                & (centers - extent[:, None, :] <= projection.max(axis=1)[:, None, :] + 1e-9), axis=2)
            touched[ids] |= np.any(overlap & possible[:, ids], axis=0)
        return int(touched.sum())

class _LeanGeometry(_BatchedGeometry):
    def _footprint_cost(self, free, x, y, heading):
        if self._collision_free is not free:
            self._collision_free = free
            self._unsafe_integral = cv2.integral((free[:74] == 0).astype(np.uint8))
        poses = [(float(b.position.x), float(b.position.y), float(b.angle), polygons, radius)
                 for b, polygons, radius in self._fixture_cache]
        lo_x = math.ceil(min(42 + 1.3608 * (px - r) for px, py, h, polys, r in poses) - .5)
        hi_x = math.floor(max(42 + 1.3608 * (px + r) for px, py, h, polys, r in poses) + .5)
        lo_y = math.ceil(min(63 - 1.701 * (py + r) for px, py, h, polys, r in poses) - .5)
        hi_y = math.floor(max(63 - 1.701 * (py - r) for px, py, h, polys, r in poses) + .5)
        xa, xb = max(0, lo_x), min(83, hi_x)
        ya, yb = max(0, lo_y), min(73, hi_y)
        if lo_x >= 0 and hi_x < 84 and lo_y >= 0 and hi_y < 74:
            ii = self._unsafe_integral
            if ii[yb + 1, xb + 1] - ii[ya, xb + 1] - ii[yb + 1, xa] + ii[ya, xa] == 0:
                return 0
            # nonzero preserves the full-grid filter's row-major cell order.
            yy, xx = np.nonzero(free[lo_y:hi_y + 1, lo_x:hi_x + 1] == 0)
            cells = np.column_stack((xx + lo_x, yy + lo_y)).astype(np.float64)
        else:
            # Outside-image cells remain unsafe; retain the original grid path.
            yy, xx = np.mgrid[lo_y:hi_y + 1, lo_x:hi_x + 1]
            xx, yy = xx.ravel(), yy.ravel()
            inside = (xx >= 0) & (xx < 84) & (yy >= 0) & (yy < 74)
            unsafe = ~inside
            unsafe[inside] = free[yy[inside], xx[inside]] == 0
            cells = np.column_stack((xx[unsafe], yy[unsafe])).astype(np.float64)
        if not len(cells):
            return 0
        transforms, offsets = [], []
        for px, py, h, polygons, radius in poses:
            c, sn = math.cos(h), math.sin(h)
            transforms.append([[1.3608 * c, -1.701 * sn], [-1.3608 * sn, -1.701 * c]])
            offsets.append([42 + 1.3608 * px, 63 - 1.701 * py])
        transforms = np.asarray(transforms)
        offsets = np.asarray(offsets)
        touched = np.zeros(len(cells), bool)
        cells_plus = cells[None, :, :] + .5
        cells_minus = cells[None, :, :] - .5
        for indices, local in self._geometry_groups:
            poly = local @ transforms[indices] + offsets[indices, None, :]
            poly_min = poly.min(axis=1)
            poly_max = poly.max(axis=1)
            possible = (np.all(cells_plus >= poly_min[:, None, :], axis=2)
                        & np.all(cells_minus <= poly_max[:, None, :], axis=2)
                        & ~touched[None, :])
            # Only the union of broad-phase candidates needs projection. Full
            # per-polygon broad-phase masks are still applied after batched SAT.
            ids = np.flatnonzero(np.any(possible, axis=0))
            if not len(ids):
                continue
            edges = np.roll(poly, -1, axis=1) - poly
            normals = np.stack((-edges[:, :, 1], edges[:, :, 0]), axis=2)
            axes = normals.transpose(0, 2, 1)
            projection = poly @ axes
            projection_min = projection.min(axis=1)
            projection_max = projection.max(axis=1)
            centers = cells[ids][None, :, :] @ axes
            extent = .5 * np.abs(normals).sum(axis=2)
            overlap = np.all(
                (centers + extent[:, None, :] >= projection_min[:, None, :] - 1e-9)
                & (centers - extent[:, None, :] <= projection_max[:, None, :] + 1e-9), axis=2)
            touched[ids] |= np.any(overlap & possible[:, ids], axis=0)
        return int(touched.sum())

def _prepare_geometry(self):
    groups = {}
    for body_index, (_, polygons, _) in enumerate(self._fixture_cache):
        for polygon in polygons:
            groups.setdefault(len(polygon), []).append((body_index, polygon))
    self._geometry_groups = tuple(((np.array([index for index, _ in entries], dtype=np.intp), np.stack([polygon for _, polygon in entries])) for entries in groups.values()))


class Agent(_LeanGeometry, _FastBeam, _CachedBeam):
    def __init__(self):
        self._fast_max_children = 256
        self._fast_deadline_seconds = 4.0
        super().__init__()
        _prepare_geometry(self)

    def act(self, observation):
        return super().act(observation)


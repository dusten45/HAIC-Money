from haic_agent.minimum_clearance_runtime import MinimumClearanceAgent
class Agent:
    def __init__(self): self.driver = MinimumClearanceAgent()
    def reset(self, observation): self.driver.reset(observation)
    def act(self, observation): return self.driver.act(observation)
    def last_step_diagnostics(self): return self.driver.last_step_diagnostics()
